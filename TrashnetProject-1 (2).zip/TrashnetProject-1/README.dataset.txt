# TrashnetProject > 2024-10-14 10:39pm
https://universe.roboflow.com/aqibs-workspace/trashnetproject

Provided by a Roboflow user
License: CC BY 4.0

